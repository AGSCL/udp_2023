##script, comentario
set.seed(112);base_datos<-data.frame(esto=rnorm(1:100))